import { useState } from 'react';
import axios from 'axios';

export default function Home() {
  const [prompt, setPrompt] = useState('');
  const [file, setFile] = useState(null);
  const [status, setStatus] = useState('Idle');
  const [videoUrl, setVideoUrl] = useState('');

  async function generateVideo() {
    const form = new FormData();
    form.append('prompt', prompt);
    form.append('image', file);
    setStatus('Processing...');

    try {
      const res = await axios.post('/api/generate-video', form);
      if (res.data?.video_url) {
        setVideoUrl(res.data.video_url);
        setStatus('Done');
      } else {
        setStatus('Error: No video returned');
      }
    } catch {
      setStatus('Error during generation');
    }
  }

  return (
    <main className='flex flex-col items-center justify-center min-h-screen bg-gray-50 p-8'>
      <div className='bg-white rounded-2xl shadow-lg p-6 w-full max-w-md'>
        <h1 className='text-2xl font-bold mb-4 text-center'>Sora Video Gen 9:16</h1>
        <textarea
          className='border rounded-md w-full p-3 mb-4'
          placeholder='Describe your video prompt...'
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
        />
        <input type='file' accept='image/*' onChange={(e) => setFile(e.target.files[0])} className='mb-4' />
        <button onClick={generateVideo} className='w-full bg-blue-600 text-white py-2 rounded-lg'>
          Generate Video
        </button>
        <p className='mt-4 text-center'>Status: {status}</p>
        {videoUrl && (
          <video src={videoUrl} controls className='mt-4 rounded-lg w-full aspect-[9/16]' />
        )}
      </div>
    </main>
  );
}

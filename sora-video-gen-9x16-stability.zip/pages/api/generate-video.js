import formidable from 'formidable';
import fs from 'fs';
import FormData from 'form-data';

export const config = { api: { bodyParser: false } };

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  const form = new formidable.IncomingForm();

  form.parse(req, async (err, fields, files) => {
    if (err) return res.status(500).json({ error: 'Form parse failed' });

    const prompt = fields.prompt || 'A cinematic scene';
    const filePath = files?.image?.filepath;
    if (!filePath) return res.status(400).json({ error: 'Missing image upload' });

    try {
      const apiKey = process.env.STABILITY_API_KEY;
      if (!apiKey) return res.status(500).json({ error: 'Missing STABILITY_API_KEY' });

      const formData = new FormData();
      formData.append('image', fs.createReadStream(filePath));
      formData.append('prompt', prompt);
      formData.append('aspect_ratio', '9:16');

      const response = await fetch('https://api.stability.ai/v2beta/image-to-video', {
        method: 'POST',
        headers: { Authorization: `Bearer ${apiKey}`, Accept: 'application/json' },
        body: formData
      });

      const result = await response.json();
      res.status(response.ok ? 200 : response.status).json(result);
    } catch (error) {
      res.status(500).json({ error: 'Server error', detail: error.message });
    }
  });
}

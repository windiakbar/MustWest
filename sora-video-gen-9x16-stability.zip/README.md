# Sora Video Gen — 9:16 (Stability AI Integrated)

A deploy-ready Next.js app connected to Stability AI’s Stable Video Diffusion API for vertical (9:16) video generation.

## 🚀 Deployment
1. Upload to GitHub
2. Deploy via Vercel
3. Add environment variable `STABILITY_API_KEY` in Vercel dashboard

## 💻 Run locally
```bash
npm install
npm run dev
```
Then open http://localhost:3000
